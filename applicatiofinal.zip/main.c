#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <time.h>

// Headers des modules
#include "demande.h"
#include "credit.h"
#include "statistique.h"
#include "paiement.h"
#include "espaceClientComplet.h"
#include "espaceAdmin.h"
#include "client.h"
#include "compteClient.h"
#include "style.h"


void menuClient(void);

int main() {
    int choix;

    do {
        clear();
        printf(CYAN "------------------------------------------------------------" RESET);
        printf("\n          SYSTEME DE GESTION FINANCIERE BANCAIRE            ");
        printf(CYAN "\n------------------------------------------------------------" RESET "\n");

        printf("\n MENU PRINCIPAL :\n");
        printf("  1. Mode Administrateur\n");
        printf("  2. Mode Client\n");
        printf("  3. Quitter\n");
        printf("\n Choix : ");

        if (scanf("%d", &choix) != 1) {
            while(getchar() != '\n');
            choix = 0;
        }
        while(getchar() != '\n');

        switch (choix) {
            case 1:
                espaceAdminComplet();
                break;
            case 2:
                menuClient();
                break;
            case 3:
                printf("\n Arret du programme. Au revoir.\n");
                break;
            default:
                printf(ROUGE "\n [!] Option invalide. Appuyez sur Entree..." RESET);
                getchar();
                break;
        }
    } while (choix != 3);

    return 0;
}


// ==========================
// Menu Client
// ==========================
void menuClient(void) {
    CompteClientNode *compteConnecte;
    int choix;

    compteConnecte = espaceClientComplet();
    if (!compteConnecte) {
        printf(RED "�chec de la connexion. Retour au menu principal.\n" RESET);
        return;
    }

    /* ===== AFFICHAGE DU MENU ===== */
    printf(L_GREEN BOLD "\n--- CLIENT ID %d : Menu ---\n" RESET, compteConnecte->compte.client.ID);
    printf(YELLOW "1. Soumettre une nouvelle demande\n" RESET);
    printf(YELLOW "2. Voir l'historique de mes demandes\n" RESET);
    printf(YELLOW "3. Voir mes credits actifs\n" RESET);
    printf(YELLOW "4. Voir mon resume financier (Statistiques)\n" RESET);
    printf(YELLOW "5. Simuler mon credit\n" RESET);
    printf(YELLOW "6. Voir les offres disponibles\n" RESET);
    printf(YELLOW "7. Modifier mes informations personnelles\n" RESET);
    printf(YELLOW "8. Retour au Menu Principal\n" RESET);
    printf("Choix: ");

    if (scanf("%d", &choix) != 1) {
        while (getchar() != '\n');
        free(compteConnecte);
        return;
    }
    while (getchar() != '\n');

    /* ===== Boucle d'attente pour retour ===== */
    do {
        printf(YELLOW "\n8. Retour au Menu Principal\n" RESET);
        printf("Choix: ");
        if (scanf("%d", &choix) != 1) {
            while(getchar() != '\n');
            choix = 0;
        }
        while(getchar() != '\n');
    } while (choix != 8);

    printf(GREEN BOLD "Deconnexion Client.\n" RESET);
    free(compteConnecte);
}
