
#include "espaceAdmin.h"
#include "compteClient.h"
#include "client.h"
#include "credit.h"
#include "style.h"
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include "demande.h"
#include "statistique.h"

#define ADMIN_ID "admin"
#define ADMIN_PASSWORD "admin123"
#define ADMIN_FILE "admin.txt"

// Fonction pour charger les identifiants admin depuis un fichier
int chargerIdentifiantsAdmin(char *id, char *password, int taille) {
    FILE *f = fopen(ADMIN_FILE, "r");
    if (!f) {
        f = fopen(ADMIN_FILE, "w");
        if (f) {
            fprintf(f, "%s\n%s\n", ADMIN_ID, ADMIN_PASSWORD);
            fclose(f);
        }
        strcpy(id, ADMIN_ID);
        strcpy(password, ADMIN_PASSWORD);
        return 1;
    }

    if (fgets(id, taille, f)) {
        id[strcspn(id, "\n")] = 0;
        if (fgets(password, taille, f)) {
            password[strcspn(password, "\n")] = 0;
            fclose(f);
            return 1;
        }
    }
    fclose(f);
    return 0;
}

// Fonction d'authentification admin
int authentifierAdmin(void) {
    char idSaisi[50];
    char passwordSaisi[50];
    char idAdmin[50];
    char passwordAdmin[50];

    printf("\n" GRAS"========================================" RESET);
    printf("\n" CYAN "        ECRAN DE CONNEXION ADMIN" RESET);
    printf("\n"GRAS "========================================" RESET);
    printf("\n" BLANC_GRAS "  BIENVENUE DANS L'ESPACE ADMIN" RESET);
    printf("\n" GRAS "========================================" RESET "\n\n");

    chargerIdentifiantsAdmin(idAdmin, passwordAdmin, sizeof(idAdmin));

    printf(GRAS "ID Admin : " RESET);
    if (scanf("%49s", idSaisi) != 1) {
        while(getchar() != '\n');
        return 0;
    }
    while(getchar() != '\n');

    printf(GRAS"Mot de passe : " RESET);
    // Note : Dans un vrai projet, on masquerait les caract�res ici
    if (scanf("%49s", passwordSaisi) != 1) {
        while(getchar() != '\n');
        return 0;
    }
    while(getchar() != '\n');

    if (strcmp(idSaisi, idAdmin) == 0 && strcmp(passwordSaisi, passwordAdmin) == 0) {
        printf("\n" BLANC_GRAS " Authentification reussie ! Bienvenue." RESET "\n");
        return 1;
    } else {
        printf("\n" ROUGE " Echec de l'authentification. ID ou mot de passe incorrect." RESET "\n");
        return 0;
    }
}

void menuAdmin(void) {
    int idClient = 0, modeAdmin = 1; // modeAdmin � 1 car on est dans l'espace Admin
    char choix;

    do {
            clear();
        printf("\n" CYAN "=== MENU ADMINISTRATEUR ===" RESET "\n");
        printf("A. Gestion des clients\n");
        printf("B. Gestion des comptes clients\n");
        printf("C. Gestion des credits\n");
        printf("D. Gestion des paiements\n");
        printf("E. Gestion des demandes\n");
        printf("F. Statistiques\n");
        printf("G. Sauvegarde / Restauration\n");
        printf(VERT "0. Retour au Menu Principal" RESET "\n");
        printf("---------------------------\n");
        printf(GRAS "Votre choix : " RESET);

        scanf(" %c", &choix);
        while(getchar()!='\n');

        switch(choix) {
            case 'A': case 'a': menuGestionClients(); break;
            case 'B': case 'b': menuGestionComptes(); break;
            case 'C': case 'c': menuGestionCredits(); break;
            case 'D': case 'd': menuGestionPaiements(); break;
            case 'E': case 'e': menuDemandes(idClient, modeAdmin); break;
            case 'F': case 'f': sousmenuStatistique(); break;

            case 'G': case 'g': {
                printf(GRAS "Lancement de la sauvegarde..." RESET "\n");
                CompteClientNode *comptes = chargerComptesFichier();
                if (sauvegarderComptesFichier(comptes)) {
                    printf(GRAS" Sauvegarde effectuee avec succes." RESET "\n");
                } else {
                    printf(ROUGE " Erreur lors de la sauvegarde." RESET "\n");
                }
                libererListeComptes(comptes);
                break;
            }

            case '0':
                printf(GRAS "Retour au Menu Principal." RESET "\n");
                break;

            default:
                printf(ROUGE "Choix invalide. Veuillez reessayer." RESET "\n");
                break;
        }
    } while(choix != '0');
}

void espaceAdminComplet(void) {
    if (!authentifierAdmin()) {
        printf(ROUGE "Acces refuse. Retour au menu principal." RESET "\n");
        return;
    }
    menuAdmin();
}
