#ifndef STYLE_H
#define STYLE_H

#include <stdio.h>
#include <stdlib.h>

// Couleurs existantes
#define RESET "\033[0m"
#define ROUGE "\033[31m"
#define VERT "\033[32m"
#define JAUNE "\033[33m"
#define BLEU "\033[34m"
#define CYAN "\033[36m"
#define BLANC_GRAS "\033[1;37m"

// AJOUTE CES LIGNES ICI :
#define MAGENTA "\033[35m"
#define GRAS    "\033[1m"

static inline void clear(void) {
    #ifdef _WIN32
        system("cls");
    #else
        system("clear");
    #endif
}

static inline void titre(const char* texte) {
    printf("\n" BLANC_GRAS "--- %s ---" RESET "\n", texte);
}

#endif
